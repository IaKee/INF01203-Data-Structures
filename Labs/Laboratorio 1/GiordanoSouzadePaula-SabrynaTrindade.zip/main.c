#include "futebol.h"
#define N_JOGADORES 2

int main()
{

    Atleta Jogador[N_JOGADORES];

    atribui_dados(N_JOGADORES, &Jogador);
    eh_o_bom(N_JOGADORES, &Jogador);
    exibe_estatistica(N_JOGADORES, &Jogador);

    return 0;
}
